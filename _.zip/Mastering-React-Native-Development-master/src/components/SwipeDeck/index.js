import { SwipeDeck } from './SwipeDeckContainer'

export { SwipeDeck }